//
//  Constants.swift
//  Example
//
//  Created by HOANDHTB on 3/6/21.
//  Copyright © 2021 HOANDHTB. All rights reserved.
//

import UIKit

class Constants {
    static let baseURL = "http://appoverweight.tk/"
    static let pathSignin = "api_web/account/signin"
}
