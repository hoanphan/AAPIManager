//
//  ViewController.swift
//  Example
//
//  Created by HOANDHTB on 3/6/21.
//  Copyright © 2021 HOANDHTB. All rights reserved.
//

import UIKit
import AAPIManager
import RxSwift
import Alamofire

class ViewController: UIViewController, URLSessionDelegate {
    let disposeBag: DisposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.testCallAPI()
        // Do any additional setup after loading the view.
    }
    
    fileprivate func testCallAPI() {
        self.submitPost().subscribe(onNext: { response in
            print(response)
        }, onError: { error in
            print(error)
        }).disposed(by: self.disposeBag)
    }
    
    public lazy var sharedManager: Session = {
        let configuration = URLSessionConfiguration.default
        
        configuration.timeoutIntervalForRequest = 60
        configuration.timeoutIntervalForResource = 60
        
        let manager = Alamofire.Session(configuration: configuration)
        return manager
    }()
    
    func submitPost() -> Observable<String> {
        return Observable<String>.create({[weak self] observer in
            
            if(!NetworkConnectivity.isConnectedToInternet)
            {
                observer.onError(AAPIManagerError.NetWorkError)
            }
            let request: URLRequest = TrackTargetType.signIn(username: "admin@gmail.com", password: "admin@123").getRequestProtocol().getRequest()
            self?.sharedManager.request(request)
                .responseString{ response in
                    switch response.result {
                    case .success :
                        print("http code \(response.response?.statusCode ?? 0)")
                        if response.response?.statusCode == 401 || response.response?.statusCode == 403 {
                            observer.onError(AAPIManagerError.Unauthorized)
                        }else{
                            observer.onNext(response.value!)
                            observer.onCompleted()
                        }
                    case .failure(let error):
                        observer.onError(error)
                    }
            }
            return Disposables.create()
        })
    }
    
}

