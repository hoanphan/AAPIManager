//
//  TrackTargetType.swift
//  Example
//
//  Created by HOANDHTB on 3/6/21.
//  Copyright © 2021 HOANDHTB. All rights reserved.
//

import UIKit
import Alamofire
import AAPIManager

protocol BaseTargetType: TargetType {
    
}

extension BaseTargetType {
    var baseURL: String {
        return Constants.baseURL
    }
    
    var headers: [String : String] {
        return [:]
    }
}

enum TrackTargetType {
    case signIn(username: String, password: String)
}

extension TrackTargetType: BaseTargetType {
    var method: HTTPMethod {
        return .post
    }
    
    var path: String {
        switch self {
        case .signIn:
            return Constants.pathSignin
        default:
            return ""
        }
    }
    
    var postData: [String : Any] {
        switch self {
        case .signIn(let username, let password):
            var parameter:[String:Any] = [:]
            parameter["email"] = username
            parameter["password"] = password
            return parameter
        default:
            return [:]
        }
    }
    
}
